package com.example.vehicle.tracking.system.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.vehicle.tracking.system.model.FirstUser;

@Repository

public interface FirstUserRepository extends JpaRepository<FirstUser, String>{
    
}  

    

    

    
