package com.example.vehicle.tracking.system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.vehicle.tracking.system.model.VehicleTracking;
import com.example.vehicle.tracking.system.services.VehicleTrackingServices;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class VehicleTrackingController{
    @Autowired
    VehicleTrackingServices services;

    @GetMapping("/vehiclestracking")
    public List<VehicleTracking>getTrackings(){
        return services.getAllTrackings();
    }
    @PostMapping("/vehiclestracking")
    public VehicleTracking  saveTracking(@RequestBody VehicleTracking tracking){
        return services.saveTracking(tracking);
    }
    @PutMapping("/updatevehicle/{id}")
    public VehicleTracking update(@PathVariable Long id,@RequestBody VehicleTracking tracking){
        return services.update(id,tracking);
    }

   
}