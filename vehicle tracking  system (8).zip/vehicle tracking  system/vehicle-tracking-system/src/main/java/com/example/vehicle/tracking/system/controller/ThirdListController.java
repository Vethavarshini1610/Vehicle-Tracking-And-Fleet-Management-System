package com.example.vehicle.tracking.system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.vehicle.tracking.system.model.ThirdList;
import com.example.vehicle.tracking.system.services.ThirdListServices;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ThirdListController{
    @Autowired
    ThirdListServices  services;

    @GetMapping("/vehiclelist")
    public List<ThirdList>getLists(){
        return services.getAllLists();
    }

    @PostMapping("/vehiclelist")
    public String saveList(@RequestBody ThirdList list){
         services.saveList(list);
         return "success";
    }
}