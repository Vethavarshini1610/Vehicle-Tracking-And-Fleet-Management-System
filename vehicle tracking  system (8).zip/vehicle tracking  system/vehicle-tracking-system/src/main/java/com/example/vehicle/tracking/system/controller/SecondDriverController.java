package com.example.vehicle.tracking.system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.vehicle.tracking.system.model.SecondDriver;
import com.example.vehicle.tracking.system.services.SecondDriverServices;

@RestController
@RequestMapping("/api/drivers")
@CrossOrigin(origins = "*")
public class SecondDriverController{
    @Autowired
    SecondDriverServices  services;


    @GetMapping("/details")
    public List<SecondDriver>getDrivers(){
        return services.getAllDrivers();
    }

    @PostMapping("/details")
    public String saveDriver(@RequestBody SecondDriver driver){
         services.saveDriver(driver);
         return "success";
    }

    
}