package com.example.vehicle.tracking.system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.vehicle.tracking.system.model.VehicleDetails;
import com.example.vehicle.tracking.system.services.VehicleDetailsServices;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class VehicleDetailsController{

    @Autowired
    VehicleDetailsServices  services;

    @GetMapping("/vehiclesdetails")
    public List<VehicleDetails>getVehicles(){
        return services.getAllVehicles();
    }

    @PostMapping("/vehiclesdetails")
    public String saveVehicle(@RequestBody VehicleDetails vehicle){
         services.saveVehicle(vehicle);
         return "success";
    }
}