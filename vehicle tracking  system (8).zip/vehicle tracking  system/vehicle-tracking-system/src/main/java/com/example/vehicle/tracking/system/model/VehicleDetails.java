package com.example.vehicle.tracking.system.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class VehicleDetails{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)

    private int id;


    private String vehiclenumber;
    private String drivername;
    private String status;

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }

    public String getVehiclenumber(){
        return vehiclenumber;
    }
    public void setVehiclenumber(String vehiclenumber){
        this.vehiclenumber=vehiclenumber;
    }
    public String getDrivername(){
        return drivername;
    }
    public void setDrivername(String drivername){
        this.drivername=drivername;
    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status=status;
    }

}

