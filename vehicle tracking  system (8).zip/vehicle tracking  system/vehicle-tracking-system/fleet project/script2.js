var map = L.map('map').setView([13.08784, 80.27847], 7);

var tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Remove tile errors completely
tileLayer.on('tileerror', function(error, tile) {
  // do nothing → prevents the error box
  // optionally, you could replace tile.src with a blank image
  tile.img.src = ''; 
});


var start = [13.0827, 80.2707];
var end = [10.9601, 79.3845];

let marker = L.marker(start).addTo(map);
let locations = {
  chennai: [13.08784, 80.27847],
  guindy: [13.0105, 80.2209],
  villupuram: [11.9390, 79.4861],
  thanjavur: [10.7867, 79.1378],
  kumbakonam: [10.9601, 79.3845],
  cuddalore: [11.7447, 79.7680],
  panruti: [11.7766, 79.5520],
  tindivanam: [12.2347, 79.6556]
};

let move;
let speeds = 20;
let fuels = 100;
let step = 0;


let trackingId;
function startTracking() {

  let from = document.getElementById("startpoint").value.toLowerCase();
  let to = document.getElementById("endpoint").value.toLowerCase();

  let route = [];

  if (from === "cuddalore" && to === "chennai") {
      route = ["cuddalore", "panruti", "tindivanam", "guindy", "chennai"];
  }
  else if (from === "chennai" && to === "kumbakonam") {
      route = ["chennai", "guindy", "villupuram", "thanjavur", "kumbakonam"];
  }
  else if (from === "kumbakonam" && to === "chennai") {
      route = ["kumbakonam", "thanjavur", "villupuram", "guindy", "chennai"];
  }
  else {
      alert("Route not available");
      return;
  }

  step = 0;

  let [lat, lng] = locations[route[0]];
  marker.setLatLng([lat, lng]);

  speeds = 20;
  fuels = 100;

  clearInterval(move);

  move = setInterval(function () {

      let nextPoint = locations[route[step + 1]];

      if (!nextPoint) {
           
  clearInterval(move);
  let finalSpeed=speeds;
  let finalFuel=fuels;
  console.log("FINAL VALUES:",finalSpeed,finalFuel);

  let vehiclenumber=localStorage.getItem("vehicle-number");
  let drivername=localStorage.getItem("driver-name");
  let trips=JSON.parse(localStorage.getItem("trips"))||[];
  let trip=trips.find(t=> t.vehiclenumber===vehiclenumber && t.drivername===drivername);
  if(trip){
    trip.status="active";
    localStorage.setItem("trips",JSON.stringify(trips));
  }


  fetch(`http://localhost:8080/api/updatevehicle/${trackingId}`,{
    method:"PUT",
    headers:{
      "Content-Type":"application/json",
    },
    body:JSON.stringify({
      endSpeed:parseFloat(finalSpeed),
      endfuel:parseFloat(finalFuel)
    })
  });
  speeds = 0;

  document.querySelector(".speed").value = 0
  document.querySelector(".fuel").value=parseFloat(fuels).toFixed(1);
      alert("Reached Destination");
      window.location.href="page2a.html";
      return;
    }

      let [endLat, endLng] = nextPoint;

      let distance = Math.sqrt(
          (endLat - lat) ** 2 + (endLng - lng) ** 2
      );

      if (distance < 0.001) {
          step++;
          return;
      }

      lat += (endLat - lat) * 0.2;
      lng += (endLng - lng) * 0.2;

      marker.setLatLng([lat, lng]);

      speeds += 0.5;

      if (fuels > 5) {
          fuels -= 0.2;
      }
      document.querySelector(".speed").value=speeds.toFixed(1);
      document.querySelector(".fuel").value=fuels.toFixed(1);

  }, 300);

  fetch('http://localhost:8080/api/vehiclestracking', {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      fromLocation:from,
      toLocation:to,
      startspeed: parseInt(speeds),
      startfuel: parseInt(fuels),
      status:"STARTED"

    })
  })
    .then(res => res.json())
    .then(data => {
    trackingId=data.id;
    });
    

  
}
function stop() {


  clearInterval(move);
  speeds = 0;
  document.querySelector(".speed").value=0;
  document.querySelector(".fuel").value=parseFloat(fuels).toFixed(1);
  alert("Vehicle Stopped");
  return;
 
}


