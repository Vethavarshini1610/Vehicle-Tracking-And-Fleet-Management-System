package com.example.vehicle.tracking.system.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class VehicleTracking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String fromLocation;
    private String toLocation;
    private double startspeed;
    private double startfuel;
    private double endspeed;
    private double endfuel;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }



    public double getStartspeed() {
        return startspeed;
    }

    public void setStartspeed(double startspeed) {
        this.startspeed = startspeed;
    }

    public double getStartfuel() {
        return startfuel;
    }

    public void setStartfuel(double startfuel) {
        this.startfuel = startfuel;
    }
    public double getEndspeed(){
        return endspeed;
    }
    public void setEndspeed(double endspeed){
        this.endspeed=endspeed;
    }
    public double getEndfuel(){
        return endfuel;
    }
    public void setEndfuel(double endfuel){
        this.endfuel=endfuel;

    }
}
