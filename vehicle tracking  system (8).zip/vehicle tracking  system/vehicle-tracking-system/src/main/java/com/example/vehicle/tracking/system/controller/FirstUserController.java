package com.example.vehicle.tracking.system.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.vehicle.tracking.system.model.FirstUser;
import com.example.vehicle.tracking.system.services.FirstUserServices;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class FirstUserController{
    @Autowired
    FirstUserServices  services;

    @GetMapping("/users")
    public List<FirstUser>getUsers(){
        return services.getAllUsers();
    }

    @PostMapping("/users")
    public String saveUser(@RequestBody FirstUser user){
         services.saveUser(user);
         return "success";
    }

}