package com.example.vehicle.tracking.system.services;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.vehicle.tracking.system.model.VehicleTracking;
import com.example.vehicle.tracking.system.repository.VehicleTrackingRepo;

@Service
public class VehicleTrackingServices{
    @Autowired
    VehicleTrackingRepo repo;

    public List<VehicleTracking>getAllTrackings(){
        return repo.findAll();
    }
    public VehicleTracking saveTracking(VehicleTracking tracking){
        return repo.save(tracking);
    }
    public VehicleTracking update(Long id , VehicleTracking vehicle){
      Optional<VehicleTracking>optional=repo.findById(id);
      if(optional.isPresent()){
        VehicleTracking existing = optional.get();
        existing.setEndspeed(vehicle.getEndspeed());
        existing.setEndfuel(vehicle.getEndfuel());


        return repo.save(existing);
    }else{
        throw new RuntimeException("VehicleID"+id+"not found");
     
    }
    

 
}
}