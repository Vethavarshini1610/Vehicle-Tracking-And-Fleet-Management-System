package com.example.vehicle.tracking.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleTrackingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleTrackingSystemApplication.class, args);
	}

}
