function login() {
    var username = document.getElementById("user-name").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    if (username === "" || email === "" || password === "") {
        alert("please enter all above details");
        return
    }
    fetch('http://localhost:8080/api/users', {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            username: username,
            email: email,
            password: password
        })
    })
        .then(res => res.text())
        .then(data => {
            if (data === "success") {
                alert("Successfully Upload");
            } else {
                alert("Its Error ");
            }
        });


    setTimeout(() => {
        window.location.href = "menu.html";
    }, 3000);


}
















