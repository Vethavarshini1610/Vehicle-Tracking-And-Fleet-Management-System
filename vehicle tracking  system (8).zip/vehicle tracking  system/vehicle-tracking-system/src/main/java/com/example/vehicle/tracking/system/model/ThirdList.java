package com.example.vehicle.tracking.system.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ThirdList{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)

    private int id;


    private String vehiclename;
    private String vehiclenumber;


    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }

    public String getVehiclename(){
        return vehiclename;
    }
    public void setVehiclename(String vehiclename){
        this.vehiclename=vehiclename;
    }
    public String getVehiclenumber(){
        return vehiclenumber;
    }
    public void setVehiclenumber(String vehiclenumber){
        this.vehiclenumber=vehiclenumber;
    }
}